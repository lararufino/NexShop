/**
 * NexShop – Backend API (Node.js + Express)
 * -----------------------------------------
 * Objetivo: Receber dados do SDK (frontend), calcular um score de confiança
 * (0–100) e retornar uma recomendação: allow | review | deny.
 *
 * Alterações:
 * - Se for bot (payload.behavior.mouse === 'bot'):
 *    - fingerprint obrigatória (true)
 *    - tempo de permanência baixo (timeOnPageMs < 3000)
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(morgan('dev'));

// Armazenamento em memória (demo)
const events = []; // últimos N eventos
const MAX_EVENTS = 1000;
const fpSeen = new Map(); // contagem por fingerprint

// Util: clamp
const clamp = (num, min, max) => Math.max(min, Math.min(max, num));

function computeRiskScore(payload) {
  let risk = 0;

  let { client = {}, behavior = {}, fingerprint = '', page = {} } = payload || {};
  let { userAgent = '', language = '', timezone = '', ip = '' } = client;
  let { timeOnPageMs = 0, mouseMoves = 0, clicks = 0, mouse = '' } = behavior;
  const { path = '' } = page;

  // --- Ajuste para bots ---
  if(mouse === 'bot'){
    fingerprint = true;
    timeOnPageMs = Math.min(timeOnPageMs, 2000); // força tempo baixo
  }

  // 1) Tempo de permanência muito baixo + ação sensível → suspeito
  const isSensitive = ['/login','/checkout','/transfer','/pix','/reset-password'].some(p => path.includes(p));
  if(timeOnPageMs < 3000 && isSensitive) risk += 25;

  // 2) Nenhuma interação de mouse/teclado → pode ser bot/script
  if(mouseMoves < 10 && clicks === 0) risk += 15;

  // 3) Idioma + UA inconsistentes
  const ua = String(userAgent).toLowerCase();
  const lang = String(language).toLowerCase();
  if(ua.includes('windows') && !lang.startsWith('pt')) risk += 5;
  if(ua.includes('headless') || ua.includes('phantom') || ua.includes('selenium')) risk += 25;

  // 4) Fuso/Timezone incoerente
  if(timezone && !/america\/(sao_paulo|santarem|recife|fortaleza|bahia)/i.test(timezone)) risk += 5;

  // 5) Repetição anômala do mesmo fingerprint
  if(fingerprint){
    const count = (fpSeen.get(fingerprint) || 0) + 1;
    fpSeen.set(fingerprint, count);
    if(count > 10) risk += 20;
  }

  // 6) Caminhos de alto risco
  if(['/checkout','/pix','/transfer'].some(p => path.includes(p))) risk += 10;

  // 7) Clicks excessivos
  if(clicks > 40) risk += 10;

  // Score final
  const score = clamp(100 - risk, 0, 100);
  let status = 'allow';
  if(score < 50) status = 'deny';
  else if(score < 75) status = 'review';

  // Motivos
  const reasons = [];
  if(timeOnPageMs < 3000 && isSensitive) reasons.push('tempo_baixo_em_acao_sensivel');
  if(mouseMoves < 10 && clicks === 0) reasons.push('sem_interacao_humana');
  if(ua.includes('headless') || ua.includes('phantom') || ua.includes('selenium')) reasons.push('ua_automacao');
  if(timezone && !/america\/(sao_paulo|santarem|recife|fortaleza|bahia)/i.test(timezone)) reasons.push('timezone_atipico');
  if(['/checkout','/pix','/transfer'].some(p => path.includes(p))) reasons.push('rota_alto_risco');
  if(clicks > 40) reasons.push('muitos_clicks');
  if((fpSeen.get(fingerprint) || 0) > 10) reasons.push('repeticao_fingerprint');

  return { score, status, reasons };
}

// POST /api/v1/risk/score
app.post('/api/v1/risk/score', (req, res) => {
  try{
    const payload = req.body || {};
    const { score, status, reasons } = computeRiskScore(payload);

    const event = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2,8)}`,
      ts: new Date().toISOString(),
      score,
      status,
      reasons,
      payload,
      ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress,
      ua: req.headers['user-agent'] || ''
    };

    events.push(event);
    if(events.length > MAX_EVENTS) events.shift();

    return res.status(200).json({ ok: true, score, status, reasons });
  }catch(err){
    console.error('Erro /risk/score:', err);
    return res.status(500).json({ ok:false, error:'internal_error' });
  }
});

// GET /api/v1/dashboard/stats
app.get('/api/v1/dashboard/stats', (_req,res)=>{
  const last = events.slice(-200);
  const buckets = { allow:0, review:0, deny:0 };
  const avg = last.reduce((acc,e)=>acc+(e.score||0),0)/(last.length||1);
  last.forEach(e=>{ if(buckets[e.status]!==undefined) buckets[e.status]++; });

  const reasonCount = {};
  last.forEach(e=>(e.reasons||[]).forEach(r=>{ reasonCount[r] = (reasonCount[r]||0)+1; }));
  const topReasons = Object.entries(reasonCount).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([reason,count])=>({reason,count}));

  return res.json({
    ok:true,
    totalEvents:events.length,
    window:last.length,
    averageScore:Math.round((avg+Number.EPSILON)*100)/100,
    distribution:buckets,
    topReasons
  });
});

// GET /api/v1/events/recent
app.get('/api/v1/events/recent', (_req,res)=>{
  const last = events.slice(-50).reverse();
  return res.json({ ok:true, events:last });
});

// Healthcheck
app.get('/api/v1/health', (_req,res)=>{
  return res.json({ ok:true, uptime:process.uptime(), now:new Date().toISOString() });
});

// Lista de clientes (nomes reais)
app.get('/api/v1/clients', (_req,res)=>{
  res.json({
    ok:true,
    clients:[
      'Ana Silva','Bruno Oliveira','Carla Souza','Daniel Pereira','Eduarda Lima','Felipe Almeida',
      'Gabriela Costa','Henrique Martins','Isabela Rocha','João Mendes','Larissa Carvalho','Marcelo Duarte'
    ]
  });
});

app.listen(PORT, ()=>console.log(`NexShop API rodando em http://localhost:${PORT}`));
